# Reto 08 - MongoDB

## Instrucciones mínimas

1. Levanta el servidor con:
   ```bash
   npm install
   npm start
   ```

2. Importa en Postman la colección:
   - `postman/reto08_postman_collection.json`

3. Ejecuta las pruebas en el orden indicado dentro de la colección.

---
