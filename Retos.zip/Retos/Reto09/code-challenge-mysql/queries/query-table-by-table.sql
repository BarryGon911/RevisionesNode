SELECT * from autor;

SELECT * from libro;

SELECT * from usuario;

SELECT * from resena;