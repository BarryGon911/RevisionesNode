# Reto 10 - Express Validator

## Instrucciones mínimas

1. Levanta el servidor con:
   ```bash
   npm install
   npm start
   ```

2. Importa en Postman la colección:
   - `postman/reto10_postman_collection.json`

3. Ejecuta las pruebas en el orden indicado dentro de la colección.

---
