# Compliance-Postman

## Resumen
- Requests totales: **25**
- Aserciones: **30**
- Pasadas: **18**
- Falladas: **12**

## Por carpeta
- **Register (random user)** — requests: 1, aserciones: 1, fallidas: 0
- **Register (duplicate email) -> 400** — requests: 1, aserciones: 1, fallidas: 0
- **Login (new user)** — requests: 1, aserciones: 1, fallidas: 0
- **Login (wrong password) -> 400** — requests: 1, aserciones: 1, fallidas: 0
- **Login (admin)** — requests: 1, aserciones: 1, fallidas: 1
- **GET /categories (public)** — requests: 1, aserciones: 2, fallidas: 0
- **POST /categories (admin)** — requests: 1, aserciones: 1, fallidas: 1
- **PUT /categories/{id} (admin)** — requests: 1, aserciones: 1, fallidas: 1
- **DELETE /categories/{id} (admin)** — requests: 1, aserciones: 1, fallidas: 1
- **POST /categories (user) -> 401/403** — requests: 1, aserciones: 1, fallidas: 0
- **GET /products (public)** — requests: 1, aserciones: 3, fallidas: 0
- **GET /products/{id} (public)** — requests: 1, aserciones: 1, fallidas: 0
- **GET /products?page=1&limit=10 (public)** — requests: 1, aserciones: 1, fallidas: 0
- **POST /products (admin)** — requests: 1, aserciones: 1, fallidas: 1
- **PUT /products/{id} (admin)** — requests: 1, aserciones: 1, fallidas: 1
- **DELETE /products/{id} (admin)** — requests: 1, aserciones: 1, fallidas: 1
- **POST /products (user) -> 401/403** — requests: 1, aserciones: 1, fallidas: 0
- **GET /cart (user)** — requests: 1, aserciones: 1, fallidas: 0
- **POST /cart (add item) (user)** — requests: 1, aserciones: 1, fallidas: 0
- **PATCH /cart/{productId} (user)** — requests: 1, aserciones: 1, fallidas: 0
- **DELETE /cart/{productId} (user)** — requests: 1, aserciones: 1, fallidas: 1
- **POST /orders (user)** — requests: 2, aserciones: 2, fallidas: 2
- **GET /orders (user)** — requests: 1, aserciones: 2, fallidas: 0
- **GET /users?page=1&limit=10 (admin)** — requests: 1, aserciones: 2, fallidas: 2

## Rúbrica (mínimos 10)
- Categorías ≥ 10: **OK**
- Productos ≥ 10: **OK**
- Usuarios ≥ 10: **FALTA**

## Fallos detallados (12)
### 1. Login (admin)
- Carpeta: Login (admin)
- Aserción: `200 OK`
- Error: expected response to have status code 200 but got 400

### 2. POST /categories (admin)
- Carpeta: POST /categories (admin)
- Aserción: `201 Created`
- Error: expected response to have status code 201 but got 401

### 3. PUT /categories/{id} (admin)
- Carpeta: PUT /categories/{id} (admin)
- Aserción: `200 OK`
- Error: expected response to have status code 200 but got 404

### 4. DELETE /categories/{id} (admin)
- Carpeta: DELETE /categories/{id} (admin)
- Aserción: `204 No Content`
- Error: expected response to have status code 204 but got 404

### 5. POST /products (admin)
- Carpeta: POST /products (admin)
- Aserción: `201 Created`
- Error: expected response to have status code 201 but got 401

### 6. PUT /products/{id} (admin)
- Carpeta: PUT /products/{id} (admin)
- Aserción: `200 OK`
- Error: expected response to have status code 200 but got 404

### 7. DELETE /products/{id} (admin)
- Carpeta: DELETE /products/{id} (admin)
- Aserción: `204 No Content`
- Error: expected response to have status code 204 but got 404

### 8. DELETE /cart/{productId} (user)
- Carpeta: DELETE /cart/{productId} (user)
- Aserción: `204 No Content`
- Error: expected response to have status code 204 but got 200

### 9. POST /orders (user)
- Carpeta: POST /orders (user)
- Aserción: `201 Created`
- Error: expected response to have status code 201 but got 500

### 10. POST /orders (user)
- Carpeta: POST /orders (user)
- Aserción: `201 Created`
- Error: expected response to have status code 201 but got 500

### 11. GET /users?page=1&limit=10 (admin)
- Carpeta: GET /users?page=1&limit=10 (admin)
- Aserción: `200 OK`
- Error: expected response to have status code 200 but got 401

### 12. GET /users?page=1&limit=10 (admin)
- Carpeta: GET /users?page=1&limit=10 (admin)
- Aserción: `Estructura paginada`
- Error: expected { error: 'Token inválido' } to have property 'page'

