import Order from "#models/Order.js";
import Cart from "#models/Cart.js";
import Product from "#models/Product.js";

const getUserId = (user) => (user?.id || user?._id);

export const createOrder = async (req, res, next) => {
  try {
    const userId = getUserId(req.user);
    if (!userId) return res.status(401).json({ error: "No autenticado" });

    // 1) Items desde body o desde carrito
    let items = Array.isArray(req.body?.items) ? req.body.items : null;

    if (items && items.length) {
      items = items
        .map((i) => ({
          product: i.product || i.productId,
          quantity: Number(i.quantity ?? 1)
        }))
        .filter((i) => i.product && Number.isFinite(i.quantity) && i.quantity > 0);

      if (!items.length) {
        return res.status(400).json({ error: "Items inválidos" });
      }
    } else {
      const cart = await Cart.findOne({ user: userId });
      if (!cart || !cart.items?.length) {
        return res.status(400).json({ error: "No hay items para ordenar" });
      }
      items = cart.items.map((i) => ({
        product: i.product,
        quantity: Number(i.quantity || 1)
      }));
    }

    // 2) Validar existencia de productos
    const productIds = [...new Set(items.map((i) => String(i.product)))];
    const products = await Product.find({ _id: { $in: productIds } }, { price: 1 });

    if (products.length !== productIds.length) {
      return res.status(400).json({ error: "Algún producto no existe" });
    }

    const priceMap = Object.fromEntries(products.map((p) => [String(p._id), Number(p.price || 0)]));

    // 3) Items con precio y total
    const orderItems = items.map((i) => ({
      product: i.product,
      quantity: i.quantity,
      price: priceMap[String(i.product)]
    }));

    if (orderItems.some((i) => typeof i.price !== "number")) {
      return res.status(400).json({ error: "No se pudo determinar el precio de un producto" });
    }

    const total = orderItems.reduce((acc, i) => acc + i.price * i.quantity, 0);

    // 4) Crear orden
    const order = await Order.create({
      user: userId,
      items: orderItems,
      total,
      status: "created"
    });

    // 5) Vaciar carrito
    await Cart.findOneAndUpdate({ user: userId }, { $set: { items: [] } });

    return res.status(201).json(order);
  } catch (e) {
    return next(e);
  }
};

// GET /orders
export const listMyOrders = async (req, res, next) => {
  try {
    const userId = getUserId(req.user);
    if (!userId) return res.status(401).json({ error: "No autenticado" });

    const orders = await Order.find({ user: userId }).populate("items.product");
    return res.json(orders);
  } catch (e) {
    return next(e);
  }
};