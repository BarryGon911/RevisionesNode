const ecom_categorias = [
  { nombre: 'Electrónica' },
  { nombre: 'Hogar' },
  { nombre: 'Deportes' },
  { nombre: 'Moda' },
  { nombre: 'Juguetes' },
  { nombre: 'Libros' },
  { nombre: 'Belleza' },
  { nombre: 'Automotriz' },
  { nombre: 'Jardín' },
  { nombre: 'Mascotas' }
]
export default ecom_categorias
